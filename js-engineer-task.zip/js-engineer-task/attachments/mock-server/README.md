# Cars Server

## Scripts

Before running any script, please install npm dependencies with either `npm install` or `yarn`.

### `npm start` or `yarn start`

Runs the server at `http://localhost:3001`. Documentation of the available endpoints can be found at `http://localhost:3001/docs`.
