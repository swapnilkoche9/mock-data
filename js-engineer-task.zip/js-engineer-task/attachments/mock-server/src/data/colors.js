module.exports = [
  "red",
  "blue",
  "green",
  "black",
  "yellow",
  "white",
  "silver",
];
